<?php

try
    {
        $bdd = new PDO('mysql:host=localhost;dbname=college;charset=utf8', 'root', 'root');
    }
    catch(Exception $a)
    { 
        die('Erreur: '.$a->getMessage());
    }

?>