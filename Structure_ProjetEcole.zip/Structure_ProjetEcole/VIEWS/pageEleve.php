<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eleve</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <?php
        if(isset($_GET['message'])){
        echo $_GET['message'];
        }

        //appel à la base
        include "../MDLS/connexion_bdd.php";

        //preparation de la requete sur les notes de l'eleve
        $req = $bdd->prepare('SELECT * FROM notes WHERE id_user ='.$_SESSION['id'].' AND matiere = :matiere');

    ?>

    <?php echo "<h1>Bonjour ".$_SESSION['nom']." ".$_SESSION['prenom']."</h1>"; ?>
    
    <!-- bouton deconnexion -->
    <div><a href="../CTRLS/deconnexion.php"><button>Deconnexion</button></a></div>

    <!--Note de français -->

    <div id="content">
    Note en français : 
        <?php

        $req->execute(array("matiere" => "Francais"));
        

        while($donnees = $req->fetch()){
            echo "<br><b>".$donnees['note']." / 20</b> - - Le ".$donnees['date_note']."<br>";
        }
        $req->closeCursor();     
        ?>
    </div> <br><br>

    <!--Note de maths -->

    <div style="margin: 0 auto; width:25%; text-align: center;">
    Note en Maths : 
        <?php

        $req->execute(array("matiere" => "Maths"));
        

        while($donnees = $req->fetch()){
            echo "<br><b>".$donnees['note']." / 20</b> - - Le ".$donnees['date_note']."<br>";
        }
        $req->closeCursor();    
        ?>
    </div>  <br><br>

    <!--Note d'histoire -->

    <div style="margin: 0 auto; width:25%; text-align: center;">
    Note en Histoire : 
        <?php

        $req->execute(array("matiere" => "Histoire"));
        

        while($donnees = $req->fetch()){
            echo "<br><b>".$donnees['note']." / 20</b> - - Le ".$donnees['date_note']."<br>";
        }
        $req->closeCursor();  
        ?>
    </div> <br><br>

    <!--Note de sport -->

    <div style="margin: 0 auto; width:25%; text-align: center;">
    Note en Sport : 
        <?php

        $req->execute(array("matiere" => "Sport"));
        

        while($donnees = $req->fetch()){
            echo "<br><b>".$donnees['note']." / 20</b> - - Le ".$donnees['date_note']."<br>";
        }
        $req->closeCursor();    
        ?>
    </div>  <br><br>
</body>
</html>