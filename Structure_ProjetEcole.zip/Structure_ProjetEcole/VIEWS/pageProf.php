<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professeur</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <?php
        if(isset($_GET['message'])){
        echo $_GET['message'];
        }

        //appel à la base
        include "../MDLS/connexion_bdd.php";

        //query sur les eleves (categorie "2" dans ma table users)
        $req = $bdd->query('SELECT * FROM users WHERE categorie = "2"');

    ?>

    <?php echo "<h1>Bonjour ".$_SESSION['nom']." ".$_SESSION['prenom']."</h1>"; ?>

    <!-- deconnexion -->
    <div><a href="../CTRLS/deconnexion.php"><button>Deconnexion</button></a></div>

    <!-- formulaire ajout note -->
    <div style="margin: 0 auto; width:50%; text-align: center;">

            <h1>Ajouter une note à un élève</h1>
            
            <form action="../CTRLS/ajoutNote.php" method="post" style="margin-top:10%;">

                <label for="user">Eleve</label><br>
                <select name="user" required>

                    <?php 
                    // on boucle sur les résultats pour afficher une option par eleve
                    while($donnees = $req->fetch()){
                        echo "<option value='".$donnees['id']."'>".$donnees['nom']." ".$donnees['prenom']."</option>";
                    }

                    $req->closeCursor();
                    ?>

                </select><br>

                <label for="matiere">Matière</label><br>
                <select name="matiere" required>
                    <option value="Francais">Francais</option>
                    <option value="Maths">Maths</option>
                    <option value="Histoire">Histoire</option>
                    <option value="Sport">Sport</option>
                </select><br>

                <label for="note">Note</label><br><br>
                <input type="number" name="note" min="0" max="20" required>
                <br>
                <br>
                <input type="submit" value="Ajouter la note">

            </form>

        </div>
</body>
</html>