<?php 

//verification de l'existance des variables (if(isset))

    
    //recuperation des données
 
    //model connexion à la base de donnée (include)


    //Récupération de l'utilisateur et de son pass (preparation et execution de la requete)
  

    //verifier l'existance de l'adresse mail et du mot de passe dans la bdd
    
        //adresse mail inccorect

            //si le mdp est correct

                //verification du status de la personne (prof ou eleve)

                    //si c'est un prof envoi l'utilisateur vers la page prof

                    //si c'est un eleve envoi l'utilisateur vers la page eleve

        //else mot de passe inccorect
?>