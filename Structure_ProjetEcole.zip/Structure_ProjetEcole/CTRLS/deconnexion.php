<?php 
session_start();

// Suppression des variables de session et de la session
$_SESSION = array();
session_destroy();

// revoi vers la page d'accueil avec un message
$message = "Vous êtes bien déconnecté";

header('Location: ../index.php?message='.$message);
?>