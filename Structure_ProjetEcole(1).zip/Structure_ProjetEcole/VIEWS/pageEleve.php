
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eleve</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <?php
      

        //appel à la base
        

        //preparation de la requete sur les notes de l'eleve
        

    ?>

    <?php echo "<h1>Bonjour ".$_SESSION['nom']." ".$_SESSION['prenom']."</h1>"; ?>
    
    <!-- bouton deconnexion -->
   

    <!--Note de français -->

   
        <?php

      
        ?>
  

    <!--Note de maths -->

    

    <!--Note d'histoire -->

   

    <!--Note de sport -->

    
</body>
</html>