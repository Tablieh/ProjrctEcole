
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professeur</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <?php
      
        //appel à la base
       
        //query sur les eleves pour aller rechercher leur id et leur nom
     

    ?>

    <?php echo "<h1>Bonjour ".$_SESSION['nom']." ".$_SESSION['prenom']."</h1>"; ?>

    <!-- deconnexion -->
  

    <!-- formulaire ajout note -->
   
                    <?php 
                    
                    // on boucle sur les résultats pour afficher une option par eleve dans notre liste déroulante
                  
                    ?>

</body>
</html>