<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


    <?php 
    //affichage du message récupéré via l'URL s'il existe
        if(isset($_GET['message'])){
        echo $_GET['message'];
        }
    ?>


<!-- création du formulaire de connexion -->




</body>
</html>