<?php 
session_start();

// Suppression des variables de session et de la session


// revoi vers la page d'accueil avec un message

?>