<?php
//demarage session


//recupération des données avec POST


//connexion à la base de données (avec include)


//preparation de la requete pour inserer la note


//execution de la requete


?>